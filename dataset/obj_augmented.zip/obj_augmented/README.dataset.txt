# manhole_detection > 2022-10-08 11:11am
https://universe.roboflow.com/object-detection/manhole_detection-wdc0v

Provided by Roboflow
License: CC BY 4.0

